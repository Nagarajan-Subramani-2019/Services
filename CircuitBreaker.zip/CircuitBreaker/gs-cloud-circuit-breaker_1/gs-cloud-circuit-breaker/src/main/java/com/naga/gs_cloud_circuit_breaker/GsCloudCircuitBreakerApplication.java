package com.naga.gs_cloud_circuit_breaker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsCloudCircuitBreakerApplication {



	public static void main(String[] args) {
		SpringApplication.run(GsCloudCircuitBreakerApplication.class, args);
	}
}


// @RequestMapping(value = "/employee", method = RequestMethod.GET)
// @GetMapping("/employee")