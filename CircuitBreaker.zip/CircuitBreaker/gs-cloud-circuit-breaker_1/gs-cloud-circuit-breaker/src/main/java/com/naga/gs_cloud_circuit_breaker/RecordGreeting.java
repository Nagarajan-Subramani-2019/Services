package com.naga.gs_cloud_circuit_breaker;

public record RecordGreeting(long id, String content) { }