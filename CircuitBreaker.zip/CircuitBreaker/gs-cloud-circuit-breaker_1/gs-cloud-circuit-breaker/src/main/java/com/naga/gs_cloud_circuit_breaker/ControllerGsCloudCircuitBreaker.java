package com.naga.gs_cloud_circuit_breaker;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Mono;
import org.springframework.web.reactive.function.client.WebClient;

import org.springframework.beans.factory.annotation.Autowired;


@RestController
public class ControllerGsCloudCircuitBreaker {

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();
    @Autowired
    private ServiceGsCoudCircuitBreaker bService;

    @GetMapping("/greeting")
    public RecordGreeting greeting(@RequestParam(defaultValue = "World") String name) {
        return new RecordGreeting(counter.incrementAndGet(), template.formatted(name));
    }

 /*   @GetMapping("/to-read")
    public RecordGreeting toRead() {
        return WebClient.builder().build()
                .bodyToMono(String.class);
    }*/

    @GetMapping("/to-read")
    public Mono<String> toRead() {

        return WebClient.builder()
                .build()
                .get()
                .uri("http://localhost:8081/greeting")
                .retrieve()
                .bodyToMono(String.class);
    }

    @GetMapping("/to-read2")
    public Mono<String> toRead2() {
        return bService.readingList();
    }

}



//     ./mvnw clean spring-boot:run
//     ./gradlew clean bootRun
//      mvn clean spring-boot:run

//  ./gradlew bootRun --args='--server.port=8082'
//  http://localhost:8081/greeting
//  http://localhost:8081/greeting?name=Naga

// curl http://localhost:8082/greeting
// curl http://localhost:8081/greeting
// curl http://localhost:8082/to-read2
