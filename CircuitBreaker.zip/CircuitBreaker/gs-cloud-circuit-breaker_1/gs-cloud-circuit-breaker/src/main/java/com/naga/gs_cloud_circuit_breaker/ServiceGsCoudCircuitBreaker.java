package com.naga.gs_cloud_circuit_breaker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;

import org.springframework.cloud.client.circuitbreaker.ReactiveCircuitBreaker;
import org.springframework.cloud.client.circuitbreaker.ReactiveCircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class ServiceGsCoudCircuitBreaker {

    private static final Logger LOG = LoggerFactory.getLogger(ServiceGsCoudCircuitBreaker.class);


    private final WebClient webClient;
    private final ReactiveCircuitBreaker readingListCircuitBreaker;

    public ServiceGsCoudCircuitBreaker(ReactiveCircuitBreakerFactory circuitBreakerFactory) {
        this.webClient = WebClient.builder().baseUrl("http://localhost:8081").build();
        this.readingListCircuitBreaker = circuitBreakerFactory.create("greeting");
    }

    public Mono<String> readingList() {
        return readingListCircuitBreaker.run(webClient.get().uri("/greeting").retrieve().bodyToMono(String.class), throwable -> {
            LOG.warn("Error making request to book service", throwable);
            return Mono.just("Cloud Native Java (O'Reilly)");
        });
    }
}

/*
@GetMapping("/to-read")
public Mono<String> toRead() {

    return WebClient.builder()
            .build()
            .get()
            .uri("http://localhost:8081/greeting")
            .retrieve()
            .bodyToMono(String.class);
}*/