package com.naga.gs_cloud_circuit_breaker;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerGreeting {

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();

    @GetMapping("/greeting2")
    public RecordGreeting greeting(@RequestParam(defaultValue = "World") String name) {
        return new RecordGreeting(counter.incrementAndGet(), template.formatted(name));
    }
}


//     ./mvnw clean spring-boot:run
//     ./gradlew clean bootRun
//      mvn clean spring-boot:run

//  ./gradlew bootRun --args='--server.port=8082'
//  http://localhost:8082/greeting
//  http://localhost:8082/greeting?name=Naga