import io.helidon.webserver.*;

import java.net.InetAddress;
import java.util.List;
import java.net.InetAddress;

public class Main {
    public static void main (String [] args) {

        List<Product> products = new Products().getProducts();
        for (Product prod: products) {
            System.out.println(
                    prod.getPid() + "- " +
                            prod.getName() + " " +
                            prod.getPrice() + " " +
                            prod.getStock()
            );
        }

        try
        {
                    Routing routing = Routing.builder()
                .get("/productlistinbrowser", (req, res) -> {

                    StringBuilder output = new StringBuilder();

                    for (Product prod : products) {
                        output.append(prod.getPid()).append(" - ")
                                .append(prod.getName()).append(" ")
                                .append(prod.getPrice()).append(" ")
                                .append(prod.getStock()).append("\n");
                    }

                    res.send(output.toString());
                })
                .get("/productlistinbrowser/{userinput}", (req, res) -> {

                    String userinput = req.path().param("userinput");

                    for (Product prod : products) {

                        if (String.valueOf(prod.getPid()).equals(userinput)) {

                            String details =
                                    "Product ID: " + prod.getPid() +
                                            "\nName: " + prod.getName() +
                                            "\nPrice: " + prod.getPrice() +
                                            "\nStock: " + prod.getStock();

                            res.send(details);
                            return;
                        }
                    }

                    res.status(404).send("Product not found: " + userinput);
                })

                .build();



            ServerConfiguration config=ServerConfiguration.builder().bindAddress(InetAddress.getLocalHost()).port(8888).build();

        WebServer ws= WebServer.create(config,routing);

        ws.start();
        }
catch (Exception e)
{
    System.out.println(e.getCause());
    System.out.println(e.getMessage());
}

        System.out.println();
        System.out.println("completed successfully");
        System.out.println();

        //new UI();
    }
}